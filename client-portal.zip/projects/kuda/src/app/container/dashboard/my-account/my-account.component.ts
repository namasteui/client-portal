import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from "rxjs";
import { MyPoliciesService } from "@app/services/my-policies.service";
import { AuthService } from '@app/core/auth/auth.service';

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.scss']
})
export class MyAccountComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  policy: Array<any> = [];
  totalDueAmount: string;
  totalPaidAmount: string;

  constructor(
    private policyService: MyPoliciesService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    //const clientId = this.authService.getToken();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      order: [],
    };

    this.policyService.getMyAccountPolicies({ type: 'ALL' })
    .subscribe( res => {
      if(res['posts'] && res['posts']['valid'] === 'YES')
      this.policy = res['posts']['policyListDetails'];
        this.totalDueAmount = res['posts']['totalDueAmount'];
        this.totalPaidAmount = res['posts']['totalPaidAmount'];
        this.dtTrigger.next();
    }, err => console.log( err))
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }

}
