import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


import { MyPoliciesService } from '@app/services/my-policies.service';

@Component({
    selector: 'app-animal-details',
    templateUrl: './animal-details.component.html',
    styleUrls: ['./animal-details.component.css']
})
export class AnimalDetailsComponent implements OnInit {
    animalDetails: Object = {};
    animalId: string;
    keyValues = [];
    constructor(
        private policyService: MyPoliciesService,
        private route: ActivatedRoute,
        private modalService: NgbModal
    ) {}

    ngOnInit() {
        const animalId = this.animalId = this.route.snapshot.params['animalId'];
        this.policyService
            .getAnimalDetails({ animalId, type: 'animal' })
            .subscribe(res => {
                if (res['posts']['valid'] === 'YES') {
                    this.animalDetails = res['posts']['AnimalDetails'];
                    this.keyValues = Object.entries(this.animalDetails).map(
                        ([type, value]) => ({ type, value })
                    );
                }
            });
    }

    openAddClaim(content) {
        this.modalService.open(content, {size: 'lg' });
    }
}
