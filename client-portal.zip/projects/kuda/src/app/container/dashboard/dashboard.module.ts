import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { NgbModule, NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';

import { DashboardRoutingModule, DASHBOARD_COMPONENTS } from './dashboard-routing.module';


@NgModule({
  declarations: [
    ...DASHBOARD_COMPONENTS,
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    NgbModule,
    NgbPaginationModule
  ]
})
export class DashboardModule { }
