import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from "rxjs";

import { MyPoliciesService } from '@app/services/my-policies.service';
import { AuthService } from '@app/core/auth/auth.service';

@Component({
  selector: 'app-race-horses',
  templateUrl: './race-horses.component.html',
  styleUrls: ['./race-horses.component.scss']
})
export class RaceHorsesComponent implements OnInit, OnDestroy {
  @ViewChild(DataTableDirective)
  datatableElement: DataTableDirective;
  
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  horses: Array<any> = [];

  constructor(
    private policyService: MyPoliciesService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    //const clientId = this.authService.getToken();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      order: [],
      columnDefs: [
        {
          targets: 4,
          orderable: false
        },
        {
          targets: 5,
          orderable: false
        },
        {
          targets: 6,
          orderable: false
        },
        {
          targets: 7,
          orderable: false
        },
        {
          targets: 8,
          orderable: false
        },
        {
          targets: 9,
          orderable: false
        },
        {
          targets: 10,
          orderable: false
        }
      ]
    };

    this.policyService.getRaceHorses({ type: '' })
    .subscribe( res => {
      if(res['posts'] && res['posts']['valid'] === 'YES') 
        this.horses = res['posts']['horseListDetails'];

        this.dtTrigger.next();
        this.columnFilter();
      
    }, err => console.log( err ));
  }

  columnFilter() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.columns().every(function() {
        const that = this;
        $('input, select', this.footer()).on('keyup change', function() {
          if(that.index('5')){
            if(this['value'] == ''){
              that.search(this['value']).draw();
            } else {
              that.search("^" + this['value'] + "$", true, true, true).draw();
            }            
          } else if (that.search() !== this['value']) {
            that.search(this['value']).draw();
          }
        });
      });
    });
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }

}
