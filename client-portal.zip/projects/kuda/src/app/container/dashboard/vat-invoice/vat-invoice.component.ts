import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { MyPoliciesService } from '@app/services/my-policies.service';
import { AuthService } from '@app/core/auth/auth.service';

@Component({
  selector: 'app-vat-invoice',
  templateUrl: './vat-invoice.component.html',
  styleUrls: ['./vat-invoice.component.scss']
})
export class VatInvoiceComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(DataTableDirective)
  datatableElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  vats: Array<any> = [];
  constructor(
    private vatService: MyPoliciesService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    //const clientId = this.authService.getToken();

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      responsive: true,
      order: [],
      columnDefs: [
        {
          targets: 4,
          orderable: false
        }
      ]
    };

    this.vatService.getVatInvoices({ type: 'VAT' }).subscribe(
      res => {
        if (res['posts'] && res['posts']['valid'] === 'YES') {
          this.vats = res['posts']['invoiceListDetails'];
        }
        this.dtTrigger.next();
        //this.columnFilter();
      },
      err => console.log(err)
    );
  }

  ngAfterViewInit() {}

  /*columnFilter() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.columns().every(function() {
        const that = this;
        $('input', this.footer()).on('keyup change', function() {
          if (that.search() !== this['value']) {
            that.search(this['value']).draw();
          }
        });
      });
    });
  }*/

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }
}
