import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyAccountService } from '@app/services/my-account.service';
import { AuthService } from '@app/core/auth/auth.service';

@Component({
    selector: 'app-client-details',
    templateUrl: './client-details.component.html',
    styleUrls: ['./client-details.component.scss']
})
export class ClientDetailsComponent implements OnInit {
    pagetitle = 'Client Details';
    client_details;
    client_name;

    constructor(
        private accountService: MyAccountService,
        private authService: AuthService,
        private route: Router
    ) {}

    ngOnInit() {
        this.client_details = this.accountService.getAccountDetails();
        if (this.client_details === null) {
            this.authService.removeToken();
            this.route.navigate(['/']);
        }
    }

    goToChangePassword(): void {
        this.route.navigate(['/dashboard/client-details/change-password']);
    }
}
