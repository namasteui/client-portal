import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { MyPoliciesService } from '@app/services/my-policies.service';

@Component({
    selector: 'app-horse-details',
    templateUrl: './horse-details.component.html',
    styleUrls: ['./horse-details.component.css']
})
export class HorseDetailsComponent implements OnInit {
    horseDetails: Object = {};
    keyValues = [];
    rootTitle: string;

    constructor(
        private policyService: MyPoliciesService,
        private route: ActivatedRoute,
        private modalService: NgbModal
    ) {}

    ngOnInit() {
        this.route.url.subscribe(params => {
            this.rootTitle = params[0].path.split('-').join(' ');
        });

        const animalId = this.route.snapshot.params['animalId'];
        this.policyService
            .getAnimalDetails({ animalId, type: 'horse' })
            .subscribe(res => {
                if (res['posts']['valid'] === 'YES') {
                    this.horseDetails = res['posts']['AnimalDetails'];
                }
            });
    }

    openAddClaim(content) {
        this.modalService.open(content, {size: 'lg' });
    }
}
