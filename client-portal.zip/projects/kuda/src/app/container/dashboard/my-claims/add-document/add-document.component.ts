import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { AuthService } from '@app/core/auth/auth.service';
import { MyPoliciesService } from '@app/services/my-policies.service';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject } from 'rxjs';

@Component({
    selector: 'app-add-document',
    templateUrl: './add-document.component.html',
    styleUrls: ['./add-document.component.css']
})
export class AddDocumentComponent implements OnInit {
    docAddForm: FormGroup;
    public errorMessage = '';
    public error = false;
    myFile:File;
    formclass;
    msg;

    @Input() modal;
    @Input() claimId;

    constructor(
        private formBuilder: FormBuilder,
        private authService: AuthService,
        private policyService: MyPoliciesService,
        private router: Router,
        private ngb: NgbModal,
        private toastrService: ToastrService
    ) { 
        
    }

    ngOnInit() {        
        this.initlializeDocForm();
    }

    initlializeDocForm(): void {
        this.docAddForm = this.formBuilder.group({
            docName: ['', [ Validators.required ]],
            docFile: ['', [ Validators.required ]]
        });
    }

    get dform() {
        return this.docAddForm.controls;
    }

    fileChange(files: any){
        this.myFile = files[0];
    }

    claimSubmit() {
        if (this.docAddForm.valid) {
            const fd = new FormData();
            const docName = this.docAddForm.value.docName;
            fd.append('claimId', this.claimId);
            fd.append('docName', docName);   
            fd.append('docFile', this.myFile);         
                
            this.policyService.addDocument(fd).subscribe(
                data => {
                    if (data.posts.success === 'yes') {
                        this.policyService.clm.next({
                            document_name: data.posts.document_name,
                            document_path: data.posts.document_path
                        });
                        this.ngb.dismissAll();                        
                    } else {
                        this.formclass = 'error';
                        this.msg = data.posts.message;
                        //this.toastrService.error('Error in uploading document. Please try again.');
                    }
                },
                err => console.log(err)
            );
        }
    }
}
