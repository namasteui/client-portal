import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MyPoliciesService } from "@app/services/my-policies.service";
import { AuthService } from '@app/core/auth/auth.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-my-claims',
  templateUrl: './my-claims.component.html',
  styleUrls: ['./my-claims.component.css']
})

export class MyClaimsComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  claims: Array<any> = [];
  constructor(
    private policyService: MyPoliciesService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    //const clientId = this.authService.getToken();

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      responsive: true,
      order: [],
      columnDefs: [
        {
          targets: 5,
          orderable: false
        },
        {
          targets: 6,
          orderable: false
        }
      ]
    };

    this.policyService.getMyClaims({ type: 'CLM' }).subscribe(
      res => {
        if (res['posts'] && res['posts']['valid'] === 'YES') {
          this.claims = res['posts']['ClaimListDetails'];
        }

        this.dtTrigger.next();
      },
      err => console.log(err)
    );
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }
}