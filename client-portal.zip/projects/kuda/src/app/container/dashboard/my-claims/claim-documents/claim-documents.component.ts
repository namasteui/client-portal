import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from "rxjs";
import { ActivatedRoute } from "@angular/router";
import { MyPoliciesService } from "@app/services/my-policies.service";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-claim-documents',
  templateUrl: './claim-documents.component.html',
  styleUrls: ['./claim-documents.component.scss']
})
export class ClaimDocumentsComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  claimId;

  claim_info: string;
  claimDocuments: Array<any> = [];
  documentIsPresent: Boolean = false;
  constructor( 
    private policyService: MyPoliciesService,
    private route: ActivatedRoute,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.showClaimDocs();    
  }

  showClaimDocs(){
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      responsive: true,
      columnDefs: [
        {
          targets: 1,
          orderable: false
        }
      ]
    };

    this.claimId = this.route.snapshot.params['claimId'];
    this.policyService.getClaimDocuments(this.claimId, 'CLM')
    .subscribe( res => {
      if( res['posts']['valid'] === 'YES') {
        this.claimDocuments = res['posts']['ClaimListDocument'];
        this.documentIsPresent = true;
        this.claim_info = res['posts']['claim_info'];
      } 
      this.dtTrigger.next();
    });
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }

  openAddDoc(content) {
    this.modalService.open(content, {size: 'lg' });
  }

}
