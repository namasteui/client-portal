import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject } from "rxjs";
import { ActivatedRoute } from "@angular/router";
import { MyPoliciesService } from "@app/services/my-policies.service";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataTableDirective } from 'angular-datatables';

@Component({
  selector: 'app-claim-uploaded-documents',
  templateUrl: './claim-uploaded-documents.component.html',
  styleUrls: ['./claim-uploaded-documents.component.scss']
})
export class ClaimUploadedDocumentsComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  claimId;
  @ViewChild(DataTableDirective)
  datatableElement: DataTableDirective;

  claim_info: string;
  claimDocuments: Array<any> = [];
  documentIsPresent: Boolean = false;
  constructor( 
    private policyService: MyPoliciesService,
    private route: ActivatedRoute,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      responsive: true,
      columnDefs: [
        {
          targets: 1,
          orderable: false
        }
      ]
    };

    this.claimId = this.route.snapshot.params['claimId'];
    this.policyService.getClaimUploadedDocuments(this.claimId, 'CLM')
    .subscribe( res => {
      if( res['posts']['valid'] === 'YES') {
        this.claimDocuments = res['posts']['ClaimListDocument'];
        this.documentIsPresent = true;
        this.claim_info = res['posts']['claim_info'];
        this.dtTrigger.next();
      } 
    });

    this.policyService.clm.subscribe((data)=>{
      if(data){
        if(typeof this.claimDocuments === 'undefined'){
          this.claimDocuments = new Array<Object>(data);
        } else {
          this.claimDocuments.push(data);
        }       
        this.rerender();
      }      
    });
  }

  rerender(): void {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }

  openAddDoc(content) {
    this.modalService.open(content, {size: 'lg', backdrop: 'static' });
  }

}
