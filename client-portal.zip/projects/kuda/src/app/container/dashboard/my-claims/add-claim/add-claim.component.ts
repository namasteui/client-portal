import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { AuthService } from '@app/core/auth/auth.service';
import { MyPoliciesService } from '@app/services/my-policies.service';
import { padNumber } from '@app/core/util/ngb-date-customer-parser-format';


@Component({
    selector: 'app-add-claim',
    templateUrl: './add-claim.component.html',
    styleUrls: ['./add-claim.component.css']
})
export class AddClaimComponent implements OnInit {
    claimAddForm: FormGroup;
    private insuredEmail: string;
    private insuredName: string;
    private insuredPhone: string;
    public countryList: Array<any>[];
    public provinceList: Array<any>[];
    public errorMessage = '';
    public error = false;
    formclass;
    msg;
    start_dt;
    end_dt;

    @Input() modal;
    @Input() policies;

    constructor(
        private formBuilder: FormBuilder,
        private authService: AuthService,
        private policyService: MyPoliciesService,
        private router: Router,
        private ngb: NgbModal
    ) { }

    ngOnInit() {
        this.initlializeClaimForm();
    }

    initlializeClaimForm(): void {
        let cd = this.authService.getClientDetails();
        this.countryList = this.authService.getCountryDetails();
        let todaysDt = padNumber((new Date()).getDate()) + '/' + padNumber(((new Date()).getMonth() + 1)) + '/' + (new Date()).getFullYear();

        cd = cd && JSON.parse(cd);
        this.insuredEmail = cd && cd.email;
        this.insuredName = (cd && `${cd.forename} ${cd.surname}`) || '';
        this.insuredPhone =
            (cd && cd.Address && `${cd.Address[0].Telephone_Number}`) || '';
        
        this.claimAddForm = this.formBuilder.group({
            claimPolicy: ['', [ Validators.required ]],
            notificationDate: [todaysDt, [ Validators.required ]],
            claimEventDate: ['', [ Validators.required ]],
            claimEventProvince: ['', [ Validators.required ]],
            claimEventCountry: ['', [ Validators.required ]],
            circumstanceLoss: ['', [ Validators.required ]],
            insuredName: [this.insuredName],
            insuredEmail: [this.insuredEmail],
            insuredPhone: [this.insuredPhone]
        });

        if(this.policies && this.policies.length){
            let pval = this.policies.map((v) => {
                return v.policy_no;
            });
            this.claimAddForm.get('claimPolicy').setValue(pval[0]);
        }
    }

    get cform() {
        return this.claimAddForm.controls;
    }

    claimSubmit() {
        if (this.claimAddForm.valid) {
            const fd = new FormData();
            const ced = this.claimAddForm.value.claimEventDate;
            
            const claimEventDate = `${padNumber(ced.day)}/${padNumber(ced.month)}/${ced.year}`;
            const notificationDate = this.claimAddForm.value.notificationDate;

            fd.append('claimPolicy', this.claimAddForm.value.claimPolicy);
            fd.append(
                'claimEventCountry',
                this.claimAddForm.value.claimEventCountry
            );
            fd.append('claimEventDate', claimEventDate);
            fd.append(
                'claimEventProvince',
                this.claimAddForm.value.claimEventProvince
            );
            fd.append('notificationDate', notificationDate);
            fd.append(
                'circumstanceLoss',
                this.claimAddForm.value.circumstanceLoss
            );
            
                
            this.policyService.addClaim(fd).subscribe(
                data => {
                    if (data.posts.success === 'yes') {
                        this.ngb.dismissAll();
                        this.router.navigate(['/dashboard/my-claims']);
                    } else {
                        this.formclass = 'error';
                        this.msg = data.posts.message;
                    }
                },
                err => console.log(err)
            );
        }
    }

    onSelectClaimCountry(id) {
        this.policyService.getProvince(id)
        .subscribe(
            data => {
                if (data['posts']['policyListDetails']) {
                    this.provinceList = data['posts']['policyListDetails'];
                } else {
                    this.provinceList = [];
                }
            },
            err => console.log(err)
        );
    }

    chkDTLength(){
        console.log(2)
        return false;
    }
}
