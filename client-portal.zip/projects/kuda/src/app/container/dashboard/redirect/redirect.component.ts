import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-redirect',
    templateUrl: './redirect.component.html',
    styleUrls: ['./redirect.component.css']
})
export class RedirectComponent implements OnInit {
    constructor(private router: Router) {}

    ngOnInit() {
        const activePolicy = localStorage.getItem('activePolicy');
        let rdUrl = '/dashboard/on-risk/sport-horse';
        switch(activePolicy){
            case 'sports':
            rdUrl = '/dashboard/on-risk/sport-horse';
            break;

            case 'race':
            rdUrl = '/dashboard/on-risk/race-horse';
            break;

            case 'game':
            rdUrl = '/dashboard/on-risk/game-animal';
            break;
        }
        this.router.navigate([rdUrl]);
    }
}
