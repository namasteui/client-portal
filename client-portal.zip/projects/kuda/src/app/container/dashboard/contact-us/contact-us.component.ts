import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ContactusService } from '@app/services/contactus.service';
import { map } from 'rxjs/operators';
import { AuthService } from '@app/core/auth/auth.service';
import { Router } from "@angular/router";
import { ActivatedRoute } from '@angular/router';
import { MyAccountService } from "@app/services/my-account.service";

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent implements OnInit {
  formclass;
  msg;
  content;
  change_request = '';
  client_details;
  client_email = '';
  client_msg = '';

  contactForm = this.contactfrm.group({
    regarding: ['', Validators.required],
    email: ['', Validators.required],
    description: ['', Validators.required],
    prefer_callback: [''],
    preferred_time: [''],
    telephone: ['']
  });

  constructor(
    private contactfrm:FormBuilder,
    private contactsrv: ContactusService,
    private router: Router,
    private auth: AuthService,
    private activeRoute: ActivatedRoute ,
    private accountService: MyAccountService
  ) { }

  ngOnInit() {
    //let clientId = this.auth.getToken();
    this.activeRoute.queryParams.subscribe(params => {
    
      if(params['change']){
        this.change_request = 'Make a change'; 
        this.client_details = this.accountService.getAccountDetails();
        this.client_email = this.client_details.email;

        if(params['change'] == 'Horse Name' || params['change'] == 'Animal Name'){
          this.client_msg = `Hello
Please amend `+params['change']+` from `+params['value']+` to ..
Regards,
`+this.client_details.forename;
        }

        if(params['change'] == 'Cover Status'){
          this.client_msg = `Hello
Please amend `+params['change']+` of `+params['from']+` from `+params['value']+` to ..
Regards,
`+this.client_details.forename;
        }

        this.contactForm.patchValue({
          regarding: this.change_request,
          email: this.client_email,
          description: this.client_msg
        });

      }  

    });
    
    this.contactsrv.getContactContent({getContact: 'Y'}).pipe(
      map((response) => response)).
      subscribe((data) => {
        let resp = data['posts'];
        this.content = resp.content;
    }); 
  }

  contactSubmit(){
    let clientId = this.auth.getToken();
    let regarding = this.contactForm.value.regarding;
    let email = this.contactForm.value.email;
    let description = this.contactForm.value.description;
    let prefer_callback = this.contactForm.value.prefer_callback;
    let preferred_time = this.contactForm.value.preferred_time;
    let telephone = this.contactForm.value.telephone;

    if(!regarding || !email || !description){
      this.formclass = 'error';
      this.msg = 'Please fill up all mandatory fields';
    } /*else if(!this.validateEmail(email)){
      this.formclass = 'error';
      this.msg = 'Invalid email address';
    }*/ else {

      this.contactsrv.contactSubmit(
        clientId, regarding, email, description, prefer_callback, preferred_time, telephone
      ).pipe(
        map((response) => response)).
        subscribe((data) => {
          let resp = data['posts'];
          if(resp.insertion == 'SUCCESS'){
            this.formclass = 'success';
            this.msg = resp.message;
            //this.msg = 'Contact has been submitted successfully';
            this.contactForm.reset();

            /*setTimeout(() => {
              this.router.navigate(['/dashboard/contact-us']);
            }, 2000);*/

          } else {
            this.formclass = 'error';
            //this.msg = 'Unable to submit contact information. Please try again later.';
            this.msg = resp.message;
          }

      });

    }
  }

  validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
  }

}
