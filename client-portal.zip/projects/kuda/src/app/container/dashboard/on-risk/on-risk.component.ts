import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-on-risk',
    templateUrl: './on-risk.component.html',
    styleUrls: ['./on-risk.component.css']
})
export class OnRiskComponent implements OnInit {
    constructor(private router: Router) {}

    ngOnInit() {}
}
