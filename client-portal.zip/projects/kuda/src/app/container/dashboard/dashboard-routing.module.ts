import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@app/core/auth/auth.guard';

// Component Load

import { ChangePasswordComponent } from '@app/container/dashboard/my-account/change-password/change-password.component';
import { MyPoliciesComponent } from '@app/container/dashboard/my-policies/my-policies.component';
import { ContactUsComponent } from '@kuda/container/dashboard/contact-us/contact-us.component';
import { ContactUsComponent as CoreContactUsComponent } from '@app/container/dashboard/contact-us/contact-us.component';
import { ContactPreferencesComponent } from '@app/container/dashboard/contact-preferences/contact-preferences.component';
import { PrivacyPolicyComponent } from '@app/container/dashboard/privacy-policy/privacy-policy.component';
import { PolicyDocumentsComponent } from '@app/container/dashboard/my-policies/policy-documents/policy-documents.component';
import { MyAccountComponent as CoreMyAccountComponent } from '@app/container/dashboard/my-account/my-account.component';

import { ClientDetailsComponent } from '@kuda/container/dashboard/client-details/client-details.component';
import { MyAccountComponent } from '@kuda/container/dashboard/my-account/my-account.component';
import { MyHorsesComponent } from '@kuda/container/dashboard/my-horses/my-horses.component';
import { HorseDetailsComponent } from '@kuda/container/dashboard/my-horses/horse-details/horse-details.component';
import { RaceHorsesComponent } from '@kuda/container/dashboard/race-horses/race-horses.component';
import { MyAnimalsComponent } from '@kuda/container/dashboard/my-animals/my-animals.component';
import { AnimalDetailsComponent } from '@kuda/container/dashboard/my-animals/animal-details/animal-details.component';
import { OnRiskComponent } from '@kuda/container/dashboard/on-risk/on-risk.component';
import { ReportsComponent } from '@kuda/container/dashboard/reports/reports.component';
import { VatInvoiceComponent } from '@kuda/container/dashboard/vat-invoice/vat-invoice.component';
import { RedirectComponent } from '@kuda/container/dashboard/redirect/redirect.component';

import { MyClaimsComponent } from '@kuda/container/dashboard/my-claims/my-claims.component';
import { ClaimDocumentsComponent } from '@kuda/container/dashboard/my-claims/claim-documents/claim-documents.component';
import { ClaimUploadedDocumentsComponent } from '@kuda/container/dashboard/my-claims/claim-uploaded-documents/claim-uploaded-documents.component';
import { AddClaimComponent } from '@kuda/container/dashboard/my-claims/add-claim/add-claim.component';
import { AddDocumentComponent } from '@kuda/container/dashboard/my-claims/add-document/add-document.component';

export const DASHBOARD_COMPONENTS = [
    CoreMyAccountComponent,
    ChangePasswordComponent,
    ClientDetailsComponent,
    MyAccountComponent,
    MyPoliciesComponent,
    PolicyDocumentsComponent,
    ContactUsComponent,
    CoreContactUsComponent,
    PrivacyPolicyComponent,
    MyHorsesComponent,
    HorseDetailsComponent,
    RaceHorsesComponent,
    MyAnimalsComponent,
    AnimalDetailsComponent,
    OnRiskComponent,
    ContactPreferencesComponent,
    ReportsComponent,
    MyClaimsComponent,
    ClaimDocumentsComponent,
    ClaimUploadedDocumentsComponent,
    VatInvoiceComponent,
    RedirectComponent,
    AddClaimComponent,
    AddDocumentComponent
];

const routes: Routes = [
    {
        path: '',
        redirectTo: 'client-details',
        pathMatch: 'full'
    },
    {
        path: 'client-details',
        component: ClientDetailsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Client Details' }
    },
    {
        path: 'client-details/change-password',
        component: ChangePasswordComponent,
        canActivate: [AuthGuard],
        data: { title: 'Change Password' }
    },
    {
        path: 'my-account',
        component: MyAccountComponent,
        canActivate: [AuthGuard],
        data: { title: 'My Account' }
    },
    {
        path: 'my-policies',
        component: MyPoliciesComponent,
        canActivate: [AuthGuard],
        data: { title: 'My Policies' }
    },
    {
        path: 'my-policies/policy-documents/:policyNo',
        component: PolicyDocumentsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Policy Documents' }
    },
    {
        path: 'contact-us',
        component: ContactUsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Contact Us' }
    },
    {
        path: 'privacy-policy',
        component: PrivacyPolicyComponent,
        canActivate: [AuthGuard],
        data: { title: 'Privacy Policy' }
    },
    {
        path: 'my-claims',
        component: MyClaimsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Claim Lists' }
    },
    {
        path: 'my-claims/claim-documents/:claimId',
        component: ClaimDocumentsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Claim Documents' }
    },
    {
        path: 'my-claims/claim-uploaded-documents/:claimId',
        component: ClaimUploadedDocumentsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Claim Uploaded Documents' }
    },
    {
        path: 'vat-invoice',
        component: VatInvoiceComponent,
        canActivate: [AuthGuard],
        data: { title: 'VAT Invoices' }
    },
    {
        path: 'on-risk',
        component: OnRiskComponent,
        children: [
            {
                path: '',
                redirectTo: 'redirect',
                pathMatch: 'full'
            },
            {
                path: 'redirect',
                component: RedirectComponent,
                canActivate: [AuthGuard]
            },
            {
                path: 'sport-horse',
                component: MyHorsesComponent,
                canActivate: [AuthGuard],
                data: { title: 'Sport Horse' }
            },
            {
                path: 'sport-horse/horse-details/:animalId',
                component: HorseDetailsComponent,
                canActivate: [AuthGuard],
                data: { title: 'Horse Details' }
            },
            {
                path: 'race-horse',
                component: RaceHorsesComponent,
                canActivate: [AuthGuard],
                data: { title: 'Race Horse' }
            },
            {
                path: 'race-horse/horse-details/:animalId',
                component: HorseDetailsComponent,
                canActivate: [AuthGuard],
                data: { title: 'Horse Details' }
            },
            {
                path: 'game-animal',
                component: MyAnimalsComponent,
                canActivate: [AuthGuard],
                data: { title: 'Game Animals' }
            },
            {
                path: 'game-animal/animal-details/:animalId',
                component: AnimalDetailsComponent,
                canActivate: [AuthGuard],
                data: { title: 'Animal Details' }
            }
        ]
    },
    {
        path: 'reports',
        component: ReportsComponent,
        canActivate: [AuthGuard],
        data: { title: 'Reports' }
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class DashboardRoutingModule {}
