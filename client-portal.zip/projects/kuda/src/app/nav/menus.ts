export const MENUS = [
    {
        label: 'Client Details',
        link: '/dashboard/client-details',
        position: 1
    },
    {
        label: 'My Account',
        link: '/dashboard/my-account',
        position: 2
    },
    {
        label: 'My Policies',
        link: '/dashboard/my-policies',
        position: 3
    },
    {
        label: 'On Risk',
        link: '/dashboard/on-risk',
        position: 4
    },
    /*{
        label: 'Sport Horse',
        link: '/dashboard/sport-horse',
        position: 4
    },
    {
        label: 'Race Horse',
        link: '/dashboard/race-horse',
        position: 5
    },
    {
        label: 'Game Animal',
        link: '/dashboard/game-animal',
        position: 6
    },*/
    {
        label: 'VAT Invoices',
        link: '/dashboard/vat-invoice',
        position: 5
    },
    {
        label: 'Claims',
        link: '/dashboard/my-claims',
        position: 6
    },
    /*{
        label: 'Reports',
        link: '/dashboard/reports',
        position: 7
    },*/
    {
        label: 'Contact Us',
        link: '/dashboard/contact-us',
        position: 8
    },
    {
        label: 'Privacy Policy',
        link: '/dashboard/privacy-policy',
        position: 9
    }
];
