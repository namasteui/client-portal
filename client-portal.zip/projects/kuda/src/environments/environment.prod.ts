export const environment = {
  production: true,
  site_title: 'Kuda',
  API_URL: 'https://kuda-staging.markit-systems.com/customerServicePortal',
  token_name: 'login_token',
  login_placeholder: 'Username'
};
