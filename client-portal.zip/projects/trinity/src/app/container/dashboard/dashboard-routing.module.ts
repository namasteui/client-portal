import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from "@app/core/auth/auth.guard";


// Component Load
import { ChangePasswordComponent } from "@app/container/dashboard/my-account/change-password/change-password.component";
import { MyAccountComponent } from '@app/container/dashboard/my-account/my-account.component';
import { MyPoliciesComponent } from '@app/container/dashboard/my-policies/my-policies.component';
import { ContactUsComponent } from '@app/container/dashboard/contact-us/contact-us.component';
import { PrivacyPolicyComponent } from '@app/container/dashboard/privacy-policy/privacy-policy.component';
import { PolicyDocumentsComponent } from '@app/container/dashboard/my-policies/policy-documents/policy-documents.component';
import { ContactPreferencesComponent } from "@app/container/dashboard/contact-preferences/contact-preferences.component";;
import { ClientDetailsComponent } from 'projects/trinity/src/app/container/dashboard/client-details/client-details.component';

export const DASHBOARD_COMPONENTS = [
  ChangePasswordComponent,
  MyAccountComponent,
  MyPoliciesComponent,
  PolicyDocumentsComponent,
  ContactUsComponent,
  ContactPreferencesComponent,
  PrivacyPolicyComponent,
  ClientDetailsComponent
];

const routes: Routes = [
  {
    path: 'client-details',
    component: ClientDetailsComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Client Details'}
  },
  {
    path: 'client-details/change-password',
    component: ChangePasswordComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Change Password'}
  },
  {
    path: 'my-policies',
    component: MyPoliciesComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'My Policies'}
  },
  {
    path: 'my-policies/policy-documents/:policyNo',
    component: PolicyDocumentsComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Policy Documents'}
  },
  {
    path: 'contact-us',
    component: ContactUsComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Contact Us'}
  },
  {
    path: 'contact-preferences',
    component: ContactPreferencesComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Contact Preferences'}
  },
  {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Privacy Policy'}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }