export const environment = {
  production: true,
  site_title: 'Trinity',
  API_URL: 'https://dev.offshoresoftwaresolutions.net/trinity/customerServicePortal',
  token_name: 'login_token',
  login_placeholder: 'Email Address'
};
