export const MENUS = [
    {
        label: 'My Account',
        link: '/dashboard/my-account',
        position: 1
    },
    {
        label: 'My Policies',
        link: '/dashboard/my-policies',
        position: 2
    },
    {
        label: 'Contact Preferences',
        link: '/dashboard/contact-preferences',
        position: 3
    },
    {
        label: 'Contact Us',
        link: '/dashboard/contact-us',
        position: 4
    },
    {
        label: 'Privacy Policy',
        link: '/dashboard/privacy-policy',
        position: 5
    }
];