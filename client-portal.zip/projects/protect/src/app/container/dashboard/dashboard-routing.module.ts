import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from "@app/core/auth/auth.guard";


// Component Load
import { ChangePasswordComponent } from "@app/container/dashboard/my-account/change-password/change-password.component";
import { MyAccountComponent } from '@app/container/dashboard/my-account/my-account.component';
import { MyPoliciesComponent } from '@app/container/dashboard/my-policies/my-policies.component';
import { ContactUsComponent } from '@app/container/dashboard/contact-us/contact-us.component';
import { PrivacyPolicyComponent } from '@app/container/dashboard/privacy-policy/privacy-policy.component';
import { PolicyDocumentsComponent } from '@app/container/dashboard/my-policies/policy-documents/policy-documents.component';
import { ContactPreferencesComponent } from "@app/container/dashboard/contact-preferences/contact-preferences.component";;
import { MyHorsesComponent } from '@app/container/dashboard/my-horses/my-horses.component';
import { HorseDetailsComponent } from '@app/container/dashboard/my-horses/horse-details/horse-details.component';
import { MyAnimalsComponent } from '@app/container/dashboard/my-animals/my-animals.component';
import { AnimalDetailsComponent } from '@app/container/dashboard/my-animals/animal-details/animal-details.component';



export const DASHBOARD_COMPONENTS = [
  ChangePasswordComponent,
  MyAccountComponent,
  MyPoliciesComponent,
  PolicyDocumentsComponent,
  ContactUsComponent,
  ContactPreferencesComponent,
  PrivacyPolicyComponent,
  MyHorsesComponent,
  HorseDetailsComponent,
  MyAnimalsComponent,
  AnimalDetailsComponent
];

const routes: Routes = [
  {
    path: 'my-account',
    component: MyAccountComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'My Account'}
  },
  {
    path: 'my-account/change-password',
    component: ChangePasswordComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Change Password'}
  },
  {
    path: 'my-policies',
    component: MyPoliciesComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'My Policies'}
  },
  {
    path: 'my-policies/policy-documents/:policyNo',
    component: PolicyDocumentsComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Policy Documents'}
  },
  {
    path: 'contact-us',
    component: ContactUsComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Contact Us'}
  },
  {
    path: 'contact-preferences',
    component: ContactPreferencesComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Contact Preferences'}
  },
  {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent,
    canActivate: [ AuthGuard ],
    data: {title: 'Privacy Policy'}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }