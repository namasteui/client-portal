import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { MENUS } from '../../nav/menus';

@Component({
    selector: 'app-app-header',
    templateUrl: './app-header.component.html',
    styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {
    client_details;
    client_name;
    navbarOpen = false;
    public menus: Array<any> = [];
    constructor(private auth: AuthService, private router: Router) {
        this.menus = MENUS;
    }

    ngOnInit() {
        this.client_details = JSON.parse(localStorage.getItem('ClientDetails'));
        this.client_name = this.client_details.forename;
    }

    logout() {
        this.auth.removeToken();
        this.router.navigate(['/']);
    }

    toggleNavbar() {
        const navBarCls = document.querySelector('#navbarSupportedContent').classList.contains('show');
        if (navBarCls) {
            document.querySelector('#navbarSupportedContent').classList.remove('show');
        }
    }
}
