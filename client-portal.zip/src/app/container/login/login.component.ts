import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { LoginService } from '../../services/login.service';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { ConnectionService } from 'ng-connection-service';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../environments/environment';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    formclass;
    msg;
    isConnected = true;
    login_placeholder = environment.login_placeholder;

    loginForm = this.login.group({
        email: ['', Validators.required],
        password: ['', Validators.required]
    });

    constructor(
        private login: FormBuilder,
        private loginsrv: LoginService,
        private router: Router,
        private auth: AuthService,
        private connectionService: ConnectionService,
        private toastrService: ToastrService
    ) {}

    ngOnInit() {
        if (this.auth.isAuthenticated()) {
            this.router.navigate(['/dashboard/client-details']);
        }

        this.connectionService.monitor().subscribe(isConnected => {
            this.isConnected = isConnected;
        });
    }

    loginSubmit() {
        const email = this.loginForm.value.email;
        const password = this.loginForm.value.password;
        if (this.loginForm.valid) {
            if (!this.isConnected) {
                this.toastrService.error('You are offline');
            } else {
                this.loginsrv
                    .checkLogin(email, password)
                    .pipe(map(response => response))
                    .subscribe(data => {
                        const resp = data['posts'];
                        if (resp.valid === 'NO') {
                            this.formclass = 'error';
                            this.msg = resp.message;
                        } else {
                            this.formclass = 'success';
                            this.msg = 'Login Successful. Redirecting...';

                            // setTimeout(() => {
                            this.auth.setToken(resp);
                            this.router.navigate(['/dashboard/client-details']);
                            // }, 2000);
                        }
                    });
            }
        } else {
            this.formclass = 'error';
            this.msg = 'Invalid credentials';
        }
    }
}
