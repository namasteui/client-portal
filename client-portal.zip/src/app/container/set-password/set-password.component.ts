import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../core/auth/auth.service';
import { FormBuilder, Validators } from '@angular/forms';
import { AbstractControl } from '@angular/forms';
import { MyAccountService } from '../../services/my-account.service';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
    selector: 'app-set-password',
    templateUrl: './set-password.component.html',
    styleUrls: ['./set-password.component.css']
})
export class SetPasswordComponent implements OnInit {
    formclass;
    msg;

    setpswForm = this.setpsw.group(
        {
            newpassword: ['', [Validators.required, Validators.minLength(6)]],
            confirmpassword: ['', Validators.required]
        },
        { validator: [this.MatchPassword] }
    );

    constructor(
        private setpsw: FormBuilder,
        private myacc: MyAccountService,
        private router: Router,
        private auth: AuthService
    ) {
        if (this.auth.isAuthenticated()) {
            this.router.navigate(['/dashboard/client-details']);
        }
    }

    ngOnInit() {
        
    }

    MatchPassword(AC: AbstractControl) {
        const password = AC.get('newpassword').value;
        const confirmpassword = AC.get('confirmpassword').value;
        if (password && confirmpassword && password !== confirmpassword) {
            AC.get('confirmpassword').setErrors({ MatchPassword: true });
        } else {
            return null;
        }
    }

    setpswSubmit() {
        if (this.setpswForm.valid) {
            const params = {
                clientId: localStorage.getItem('temp_token'),
                clientPassword: this.setpswForm.value.confirmpassword
            };
            this.myacc
                .updateClientPassword(params)
                .pipe(map(response => response))
                .subscribe(data => {
                    const resp = data['posts'];
                    if (resp.valid === 'NO') {
                        this.formclass = 'error';
                        this.msg = resp.message;
                    } else {
                        this.formclass = 'success';
                        this.msg = 'Password has been set successfully';
                        this.setpswForm.reset();
                        localStorage.removeItem('temp_token');

                        setTimeout(() => {
                            this.router.navigate(['/']);
                        }, 2000);
                    }
                });
        } else {
            let errmsg = '';
            const formControls = this.setpswForm.controls;

            if (formControls['newpassword'].errors) {
                if (formControls['newpassword'].errors.required) {
                    errmsg = 'Please provide new password';
                } else if (formControls['newpassword'].errors.minlength) {
                    errmsg = 'Password must be minimum 6 characters';
                }
            } else if (formControls['confirmpassword'].errors) {
                if (formControls['confirmpassword'].errors.required) {
                    errmsg = 'Please provide confirm password';
                } else if (
                    formControls['confirmpassword'].errors.MatchPassword
                ) {
                    errmsg = 'Password mismatched';
                }
            }
            this.formclass = 'error';
            this.msg = errmsg;
        }
    }
}
