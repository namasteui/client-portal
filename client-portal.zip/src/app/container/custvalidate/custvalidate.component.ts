import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CustvalidateService } from '../../services/custvalidate.service';
import { map } from 'rxjs/operators';
import { Router } from "@angular/router";

@Component({
  selector: 'app-custvalidate',
  templateUrl: './custvalidate.component.html',
  styleUrls: ['./custvalidate.component.scss']
})
export class CustvalidateComponent implements OnInit {

  constructor(
    private activeRoute: ActivatedRoute,
    private custsrv: CustvalidateService,
    private router: Router
  ) { }

  ngOnInit() {
    const routeParams = this.activeRoute.snapshot.params;
    const clientVar = routeParams.clientVar;
    const clientId = routeParams.clientId;

    localStorage.setItem('temp_token', clientId);

    this.custsrv.clientValidate(clientId).pipe(
      map((response) => response)).
      subscribe((data) => {
        let resp = data['posts'];
        if(resp.valid == 'YES'){
          let hasPassword = resp.hasPassword;
          if(hasPassword == 'NO'){
            localStorage.setItem('temp_token', clientId);
            this.router.navigate(['/set-password']);
          } else {
            this.router.navigate(['/']);
          }
        } else {
          this.router.navigate(['/not-found']);
        }
        
    });
    
    
  }

}
