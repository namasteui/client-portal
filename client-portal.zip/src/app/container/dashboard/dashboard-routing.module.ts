import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

const ROUTES = [];
export const DASHBOARD_COMPONENTS = [];

@NgModule({
  imports: [RouterModule.forChild( ROUTES )],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
