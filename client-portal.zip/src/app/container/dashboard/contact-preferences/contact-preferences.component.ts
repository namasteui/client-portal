import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ContactpreferenceService } from '../../../services/contact-preference.service';
import { MyPoliciesService} from '../../../services/my-policies.service';
import { map } from 'rxjs/operators';
import { AuthService } from '../../../core/auth/auth.service';

export interface MktInterface{
  email?: string;
  phone?: string;
  sms?: string;
  post?: string;
}

@Component({
  selector: 'app-contact-preferences',
  templateUrl: './contact-preferences.component.html',
  styleUrls: ['./contact-preferences.component.scss']
})
export class ContactPreferencesComponent implements OnInit {
  formclass;
  msg;
  mktData:MktInterface;

  contactprefForm = this.cprefForm.group({
    email: [''],
    phone: [''],
    sms: [''],
    post: ['']
  });

  constructor(
    private cprefForm:FormBuilder,
    private mymkt: MyPoliciesService,
    private mktsrv: ContactpreferenceService,
    private auth: AuthService 
  ) { }

  ngOnInit() {
    let clientId = this.auth.getToken();
    let params = { clientId: clientId, type: 'MKT' }

    const mkt = this.mymkt.getMyPolicies(params).subscribe((data) => { 
      this.mktData = data['posts']['marketingPermissions'];

      this.contactprefForm.setValue({
        email: this.mktData.email, 
        phone: this.mktData.phone,
        sms: this.mktData.sms,
        post: this.mktData.post
      });
    });
    
  }

  contactprefSubmit(){
    let clientId = this.auth.getToken();
    let email = this.contactprefForm.value.email;
    let phone = this.contactprefForm.value.phone;
    let sms = this.contactprefForm.value.sms;
    let post = this.contactprefForm.value.post;

    console.log(this.contactprefForm)

    this.mktsrv.contactpreferenceSubmit(
      clientId, email, phone, sms, post
    ).pipe(
      map((response) => response)).
      subscribe((data) => {
        let resp = data['posts'];
        if(resp.updation == 'SUCCESS'){
          this.formclass = 'success';
          this.msg = 'Contact Preferences has been updated successfully.';
        } else {
          this.formclass = 'error';
          this.msg = 'There is a problem on updation. Please try again.';
        }

    });
  }

}
