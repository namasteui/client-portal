import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import {
    NgbModule,
    NgbPaginationModule,
    NgbDateParserFormatter
} from '@ng-bootstrap/ng-bootstrap';

import { NgbDateCustomParserFormatter } from '@app/core/util/ngb-date-customer-parser-format';

import {
    DashboardRoutingModule,
    DASHBOARD_COMPONENTS
} from './dashboard-routing.module';

@NgModule({
    declarations: [...DASHBOARD_COMPONENTS],
    imports: [
        CommonModule,
        DashboardRoutingModule,
        ReactiveFormsModule,
        FormsModule,
        DataTablesModule,
        NgbModule,
        NgbPaginationModule
    ],
    providers: [
        {
            provide: NgbDateParserFormatter,
            useClass: NgbDateCustomParserFormatter
        }
    ]
})
export class DashboardModule {}
