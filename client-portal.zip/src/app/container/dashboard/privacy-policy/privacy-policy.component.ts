import { Component, OnInit } from '@angular/core';
import { PrivacyService } from '../../../services/privacy.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component.scss']
})
export class PrivacyPolicyComponent implements OnInit {
  content;
  docPath;
  constructor(private privacysrv: PrivacyService) { }

  ngOnInit() {
    this.privacysrv.getPrivacy().pipe(
      map((response) => response)).
      subscribe((data) => {
        let resp = data['posts'];
        this.content = resp.content;
        this.docPath = resp.doc_path;
    }); 
  }

}
