import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MyPoliciesService } from '../../../services/my-policies.service';
import { AuthService } from './../../../core/auth/auth.service';

@Component({
  selector: 'app-my-policies',
  templateUrl: './my-policies.component.html',
  styleUrls: ['./my-policies.component.scss']
})
export class MyPoliciesComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  policies: Array<any> = [];
  constructor(
    private policyService: MyPoliciesService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    //const clientId = this.authService.getToken();

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      responsive: true,
      order: [],
      columnDefs: [
        {
          targets: 5,
          orderable: false
        }
      ]
    };

    this.policyService.getMyPolicies({ type: 'POL' }).subscribe(
      res => {
        if (res['posts'] && res['posts']['valid'] === 'YES') {
          this.policies = res['posts']['policyListDetails'];
        }

        this.dtTrigger.next();
      },
      err => console.log(err)
    );
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }
}
