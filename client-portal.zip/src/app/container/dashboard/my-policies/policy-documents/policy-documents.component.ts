import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from "rxjs";
import { ActivatedRoute } from "@angular/router";

import { MyPoliciesService } from "../../../../services/my-policies.service";

@Component({
  selector: 'app-policy-documents',
  templateUrl: './policy-documents.component.html',
  styleUrls: ['./policy-documents.component.scss']
})
export class PolicyDocumentsComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  policyDocuments: Array<any> = [];
  documentIsPresent: Boolean = false;
  constructor( private policyService: MyPoliciesService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 25,
      processing: true,
      responsive: true,
      columnDefs: [
        {
          targets: 3,
          orderable: false
        }
      ]
    };

    const policyNo = this.route.snapshot.params['policyNo'];

    this.policyService.getPolicyDocuments(policyNo)
    .subscribe( res => {
      if( res['posts']['isPresent'] === 'YES') {
        this.policyDocuments = res['posts']['documentList'];
        this.documentIsPresent = true;
      } 
      this.dtTrigger.next();
    });
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
  }

}
