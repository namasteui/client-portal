import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { MyAccountService } from "../../../services/my-account.service";
import { AuthService } from "../../../core/auth/auth.service";

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.scss']
})
export class MyAccountComponent implements OnInit {
  pagetitle: string = "My Account";
  client_details;
  client_name;

  constructor( private accountService: MyAccountService,
              private authService: AuthService,
              private route: Router) { }

  ngOnInit() {
    this.client_details = this.accountService.getAccountDetails();
    if( this.client_details === null) {
      this.authService.removeToken();
      this.route.navigate(['/']);
    }
  }

}
