import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { MyAccountService } from '../../../../services/my-account.service';
import { AuthService } from '../../../../core/auth/auth.service';

@Component({
    selector: 'app-change-password',
    templateUrl: './change-password.component.html',
    styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {
    public changePassForm = this.formBuilder.group(
        {
            new_password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(15)]],
            conf_password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(15)]]
        },
        {
            validator: [this.confirmPasswordValidator]
        }
    );

    public error = false;
    public errorMessage: string;

    constructor(
        private formBuilder: FormBuilder,
        private route: Router,
        private myAccountService: MyAccountService,
        private authService: AuthService
    ) {}

    ngOnInit() {}

    get f() {
        return this.changePassForm.controls;
    }

    onChangePassword() {
        if (this.changePassForm.valid) {
            this.myAccountService
                .updateClientPassword({
                    clientPassword: this.changePassForm.value.new_password,
                    clientId: this.authService.getToken()
                })
                .subscribe(data => {
                    const resp = data['posts'];                    
                    if (resp.valid == 'NO') {
                        this.error = true;
                        this.errorMessage = resp.message;
                    } else {
                        this.route.navigate(['/dashboard/client-details']);
                    }
                });
        } else {
            const formControls = this.changePassForm.controls;
            if (formControls['new_password'].errors) {
                this.error = true;
                if (formControls['new_password'].errors.required) {
                    this.errorMessage = 'New password is required';
                } else if (formControls['new_password'].errors.minlength) {
                    this.errorMessage =
                        'New password must be at least 6 characters';
                } else if (formControls['new_password'].errors.maxlength) {
                    this.errorMessage =
                        'New password must be max 15 characters';
                }
            } else if (formControls['conf_password'].errors) {
                this.error = true;
                if (formControls['conf_password'].errors.required) {
                    this.errorMessage = 'Confirm password is required';
                } else if (formControls['conf_password'].errors.minlength) {
                    this.errorMessage =
                        'Confirm password must be at least 6 characters';
                } else if (formControls['conf_password'].errors.maxlength) {
                    this.errorMessage =
                        'Confirm password must be max 15 characters';
                }
            } else {
                this.error = true;
                if (this.changePassForm.errors) {
                    this.errorMessage = 'Passwords must match';
                }
            }
        }
    }

    confirmPasswordValidator(form: FormGroup) {
        return form.get('new_password').value ===
            form.get('conf_password').value
            ? null
            : { mismatch: true };
    }

    goToDetails(): void {
        this.route.navigate(['/dashboard/client-details']);
    }
}
