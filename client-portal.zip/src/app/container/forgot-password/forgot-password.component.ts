import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ForgotpasswordService } from '../../services/forgot-password.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  formclass;
  msg;
  login_placeholder = environment.login_placeholder;

  constructor(private forgotpswsrv: ForgotpasswordService) {}

  ngOnInit() {}

  forgotpswSubmit(f) {
    const email = f.value.email;
    if (!email) {
      this.formclass = 'error';
      this.msg = 'Please provide ' + this.login_placeholder;
    } else {
      this.forgotpswsrv
        .resetPassword(email)
        .pipe(map(response => response))
        .subscribe(data => {
          const resp = data['posts'];
          if (resp.valid === 'NO') {
            this.formclass = 'error';
            //this.msg = 'Invalid ' + this.login_placeholder;
            this.msg = resp.message;
          } else {
            this.formclass = 'success';
            this.msg = 'Password reset link has been sent to your email';
          }
          f.reset();
        });
    }
  }
}
