import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { LocationStrategy, HashLocationStrategy } from '@angular/common';


import { DataTablesModule } from 'angular-datatables';

import { LoginService } from './services/login.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APIInterceptor } from './core/interceptor/api-interceptor';

import { AppComponent } from './app.component';
import { LoaderComponent } from './themes/loader/loader.component';
import { LoginComponent } from './container/login/login.component';
import { ForgotPasswordComponent } from './container/forgot-password/forgot-password.component';
import { SetPasswordComponent } from './container/set-password/set-password.component';
import { CustvalidateComponent } from './container/custvalidate/custvalidate.component';
import { AppHeaderComponent } from './themes/app-header/app-header.component';
import { AppFooterComponent } from './themes/app-footer/app-footer.component';
import { NotFoundComponent } from './container/not-found/not-found.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotPasswordComponent,
    AppHeaderComponent,
    AppFooterComponent,
    LoaderComponent,
    SetPasswordComponent,
    CustvalidateComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({positionClass: 'toast-bottom-left', timeOut: 3000, tapToDismiss: true}),
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DataTablesModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: APIInterceptor,
      multi: true
    },
    /*{
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },*/
    LoginService
  ],
  exports : [
    LoaderComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
