import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders} from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { tap, finalize } from 'rxjs/operators';

import { LoaderService } from '../../services/loader.service';
import { environment } from '../../../environments/environment';
import { AuthService } from '@app/core/auth/auth.service';

@Injectable()
export class APIInterceptor implements HttpInterceptor {

    constructor( private loaderService: LoaderService,
                private authService: AuthService
         ) {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const params = {
            url: `${environment.API_URL}${req.url}`
        };

        if (this.authService.isAuthenticated()) {
            Object.assign(params, {
                headers : new HttpHeaders({
                    'X-Client-ID': this.authService.getToken()
                })
            });
        }


        const apiReq = req.clone(params);
        return next.handle(apiReq)
                .pipe(
                    tap(() => this.loaderService.show()),
                    finalize( () => this.loaderService.hide())
                );
    }
}
