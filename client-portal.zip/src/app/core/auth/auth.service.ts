import { Injectable } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { BehaviorSubject } from 'rxjs';

const TOKEN_NAME = environment.token_name;

interface AuthInterface {
    clientId: string;
    ClientDetails: object;
    activePolicy: string;
    countryList: string;
}

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    public isLoggedIn$ = new BehaviorSubject(this.isAuthenticated());
    constructor() {
        this.isLoggedIn$.asObservable();
    }

    isAuthenticated(): boolean {
        return !!localStorage.getItem(TOKEN_NAME);
    }

    getTokenName(): string {
        return TOKEN_NAME;
    }

    getToken(): any {
        return this.isAuthenticated() ? localStorage.getItem(TOKEN_NAME) : '';
    }

    getClientDetails(): any {
        return localStorage.getItem('ClientDetails');
    }

    getCountryDetails(): any {
        const countryList = localStorage.getItem('countryList');
        if (countryList) {
            return JSON.parse(countryList);
        }
        return [];
    }

    setToken(value: AuthInterface): void {
        localStorage.setItem(TOKEN_NAME, value.clientId);
        localStorage.setItem(
            'ClientDetails',
            JSON.stringify(value.ClientDetails)
        );
        localStorage.setItem('activePolicy', value.activePolicy);
        localStorage.setItem('countryList', JSON.stringify(value.countryList));
        this.isLoggedIn$.next(true);
    }

    removeToken(): void {
        localStorage.removeItem(TOKEN_NAME);
        localStorage.removeItem('ClientDetails');
        localStorage.removeItem('countryList');
        this.isLoggedIn$.next(false);
    }
}
