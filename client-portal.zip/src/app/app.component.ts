import { Component, OnInit, Inject } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { AuthService } from './core/auth/auth.service';

import { Title } from '@angular/platform-browser';
import { filter, mergeMap } from 'rxjs/operators';
import { map } from 'rxjs/operators';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
    pagetitle: string;
    title = 'client-portal';
    isLogin: Boolean;

    constructor(
        private router: Router,
        private auth: AuthService,
        private activatedRoute: ActivatedRoute,
        private titleService: Title
    ) {
        this.auth.isLoggedIn$.subscribe(data => {
            this.isLogin = data;
        });
    }

    ngOnInit() {

        this.router.events
            .pipe(
                filter(event => event instanceof NavigationEnd),
                map(() => this.activatedRoute),
                map(route => {
                    while (route.firstChild) {
                        route = route.firstChild;
                    }

                    return route;
                }),
                filter(route => route.outlet === 'primary'),
                mergeMap(route => route.data)
            )
            .subscribe(event => this.titleService.setTitle(event['title']));
    }
}
