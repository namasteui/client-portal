import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class ContactpreferenceService{
    constructor(private httpc: HttpClient){}

    contactpreferenceSubmit(
        clientId: string,
        email: string, 
        phone: string, 
        sms: string, 
        post: string
    ){
        const frmdata = new FormData();
        frmdata.append('clientId', clientId);
        frmdata.append('email', email);
        frmdata.append('phone', phone);
        frmdata.append('sms', sms);
        frmdata.append('post', post);

        return this.httpc.post('/customerMarketingPermissions.php', frmdata);
    }
}