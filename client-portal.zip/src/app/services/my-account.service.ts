import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

export interface ChangePasswordInterface {
  clientPassword: string;
  clientId: string;
}

@Injectable({
  providedIn: 'root'
})
export class MyAccountService {

  constructor( private http: HttpClient) { }

  updateClientPassword( params: ChangePasswordInterface ) : Observable<any> {
    const formData = new FormData();
    formData.append('clientId', params.clientId);
    formData.append('clientPassword', params.clientPassword)
    return this.http.post('/customerPassword.php', formData);
  }

  getAccountDetails() : Array<any> | null {
    const clientDetails = localStorage.getItem('ClientDetails');
    if(clientDetails) {
      return JSON.parse( clientDetails );
    } 

    return null;
  }
}
