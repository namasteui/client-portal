import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';

export interface MyPolicyInterface {
    clientId: string;
    type: string;
}

export interface MyPolInterface {
  type: string;
}

export interface MyAnimalInterface {
    animalId: string;
    type: string;
}

export interface AddClaimInterface {
    claimPolicy: string;
    notificationDate: string;
    claimEventDate: string;
    claimEventProvince: number;
    claimEventCountry: number;
    circumstanceLoss: string;
}

@Injectable({
    providedIn: 'root'
})
export class MyPoliciesService {

  public clm = new BehaviorSubject(null);
  constructor( private http: HttpClient) { 
    this.clm.asObservable();
  }

  getMyPolicies(params: MyPolInterface) : Observable<any> {
    return this.http.get('/customerMktAndPolicies.php', {
      params: {
        ...params
      }
    });
  }

  getPolicyDocuments( policyNo: string) : Observable<any> {
    return this.http.get('/customerDetailDocumentSummary.php', {
      params : {
        policyNumber: policyNo
      }
    })
  }

  getMyHorses(params: MyPolInterface) : Observable<any> {
    return this.http.get('/customerHorse.php', {
      params: {
        ...params
      }
    });
  }

  getRaceHorses(params: MyPolInterface) : Observable<any> {
    return this.http.get('/customerRaceHorse.php', {
      params: {
        ...params
      }
    });
  }

  getMyAnimals(params: MyPolInterface) : Observable<any> {
    return this.http.get('/customerAnimals.php', {
      params: {
        ...params
      }
    });
  }

  getAnimalDetails( params: MyAnimalInterface) : Observable<any> {
    return this.http.get('/customerAnimalDetails.php', {
      params : {
        ...params
      }
    })
  }

  getVatInvoices(params: MyPolInterface) : Observable<any> {
    return this.http.get('/customerVATinvoice.php', {
      params: {
        ...params
      }
    });
  }

  getMyAccountPolicies(params: MyPolInterface) : Observable<any> {
    return this.http.get('/myAccount.php', {
      params: {
        ...params
      }
    });
  }

  getReportLists(params: MyPolicyInterface) : Observable<any> {
    return this.http.get('/customerVATinvoice.php', {
      params: {
        ...params
      }
    });
  }

  getMyClaims(params: MyPolInterface) : Observable<any> {
    return this.http.get('/customerClaim.php', {
      params: {
        ...params
      }
    });
  }

  getClaimDocuments( claimId: string, type: string) : Observable<any> {
    return this.http.get('/customerClaimDetails.php', {
      params : {
        claimId: claimId,
        type: type
      }
    })
  }

  getClaimUploadedDocuments( claimId: string, type: string) : Observable<any> {
    return this.http.get('/customerClaimUploadDetails.php', {
      params : {
        claimId: claimId,
        type: type
      }
    })
  }

    getProvince( countryId ): Observable<any> {
        return this.http.get(`/getprovince.php?countryId=${countryId}`);
    }

    addClaim(params): Observable<any> {
        return this.http.post('/addClaim.php', params);
    }

    addDocument(params): Observable<any> {
      return this.http.post('/uploadDocument.php', params);
  }

  
}
