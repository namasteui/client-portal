import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class CustvalidateService{
    constructor(private httpc: HttpClient){}

    clientValidate(clientId:string){       
        return this.httpc.get('/customerValidation.php?clientId=' + clientId);
    }
}