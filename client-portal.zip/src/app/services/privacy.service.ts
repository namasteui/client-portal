import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class PrivacyService{
    constructor(private httpc: HttpClient){}

    getPrivacy(){       
        return this.httpc.get('/customerPrivacyPolicy.php?getPrivacyPolicy=Y');
    }
}