import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class ForgotpasswordService {

    constructor (private httpc: HttpClient) { }

    resetPassword(email:string){
        const frmdata = new FormData();
        frmdata.append('email', email);
        return this.httpc.post('/resetPassword.php', frmdata);
    }
}