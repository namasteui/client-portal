import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from "rxjs";

export interface LoaderInterface {
  state: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  private loaderBehaviorSubject$ = new BehaviorSubject<LoaderInterface>({state: false});
  constructor() { }

  getLoaderState(): Observable<LoaderInterface> {
    return this.loaderBehaviorSubject$.asObservable();
  }

  show() {
    this.loaderBehaviorSubject$.next({state:true});
  }

  hide() {
    this.loaderBehaviorSubject$.next({state:false});
  }
}
