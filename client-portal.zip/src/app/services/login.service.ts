import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class LoginService {
    
    constructor (private httpc: HttpClient) { }

    checkLogin(email:string, password: string){
        const frmdata = new FormData();
        frmdata.append('email', email);
        frmdata.append('clientPassword', password);
        return this.httpc.post('/customerLogin.php', frmdata);
    }

}