import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface contactUsInterface {
    getContact: string;
}

@Injectable({
    providedIn: 'root'
})

export class ContactusService{
    constructor(private httpc: HttpClient){}

    getContactContent(params: contactUsInterface) : Observable<any> {
        return this.httpc.get('/contactUs.php', {
          params: {
            ...params
          }
        });
    }

    contactSubmit(
        clientId: string,
        regarding:string, 
        email: string,
        description:string, 
        prefer_callback: string,
        preferred_time:string, 
        telephone: string
    ){
        const frmdata = new FormData();
        frmdata.append('clientId', clientId);
        frmdata.append('regarding', regarding);
        frmdata.append('email', email);
        frmdata.append('description', description);
        frmdata.append('prefer_callback', prefer_callback);
        frmdata.append('preferred_time', preferred_time);
        frmdata.append('telephone', telephone);

        return this.httpc.post('/customerDescription.php', frmdata);
    }
}