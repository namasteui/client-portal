import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './container/login/login.component';
import { ForgotPasswordComponent } from './container/forgot-password/forgot-password.component';
import { NotFoundComponent } from './container/not-found/not-found.component';
import { SetPasswordComponent } from './container/set-password/set-password.component';
import { CustvalidateComponent } from './container/custvalidate/custvalidate.component';
import { AuthGuard } from './core/auth/auth.guard';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: './container/dashboard/dashboard.module#DashboardModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent,
    data: { title: 'Forgot Password' }
  },
  {
    path: 'set-password',
    component: SetPasswordComponent,
    data: { title: 'Set Password' }
  },
  {
    path: 'custValidate/:clientVar/:clientId',
    component: CustvalidateComponent
  },
  {
    path: '',
    component: LoginComponent,
    data: { title: 'Login' }
  },
  {
    path: '**',
    component: NotFoundComponent,
    data: { title: 'Not Found' }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
