export const environment = {
  production: true,
  theme: 'kuda',
  site_title: 'Kuda',
  API_URL: 'https://kuda-staging.markit-systems.com/customerServicePortal',
  token_name: 'login_token',
  basePath: '/'
};
